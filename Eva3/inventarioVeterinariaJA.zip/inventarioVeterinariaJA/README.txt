usuarios:
  - nombre: Admin
    password: Admin123
    rol: superusuario

  - nombre: Joaquin
    password: Inacap123
    rol: usuario

  - nombre: Alejandro
    password: Inacap123
    rol: usuario